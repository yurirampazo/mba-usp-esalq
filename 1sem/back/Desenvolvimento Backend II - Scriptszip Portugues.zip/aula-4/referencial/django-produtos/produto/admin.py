from django.contrib import admin
from produto.models import Product

admin.site.register(Product)