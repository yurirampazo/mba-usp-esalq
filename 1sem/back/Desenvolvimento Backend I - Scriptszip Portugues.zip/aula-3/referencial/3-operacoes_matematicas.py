# soma +
print('1+1=',1+1)

# subtração -
print('3-1=',3-1)

# multiplicação *
print('5*6=',5*6)

# divisão /
print('10/3=',10/3)

# exponenciação **
print('2³=', 2**3)

# Modulo (resto) +
print('10/4=',10%4)